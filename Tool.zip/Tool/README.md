# WORKING
--python -m venv .env
--.env\Scripts\activate
--pip install pybase64
--pip install cryptography
--python main.py